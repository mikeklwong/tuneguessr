// Browser adapter; replace with a native audio adapter when sharing the game API with mobile.
let context: AudioContext | null = null;
let active: OscillatorNode[] = [];
export function stopAudio(){active.forEach(o=>{try{o.stop();}catch{}});active=[];}
export async function playMelody(notes:number[], volume:number){
 stopAudio(); context??=new AudioContext(); await context.resume();
 const start=context.currentTime+.04;
 notes.forEach((note,i)=>{if(!note)return; const osc=context!.createOscillator();const gain=context!.createGain();osc.type='triangle';osc.frequency.value=440*Math.pow(2,(note-69)/12);gain.gain.setValueAtTime(0,start+i*.32);gain.gain.linearRampToValueAtTime(volume*.3,start+i*.32+.015);gain.gain.exponentialRampToValueAtTime(.001,start+i*.32+.29);osc.connect(gain);gain.connect(context!.destination);osc.start(start+i*.32);osc.stop(start+i*.32+.3);active.push(osc);});
 return notes.length*.32;
}
