// Original synthesized renditions of public-domain compositions; no commercial recordings.
export type Melody = { title: string; aliases: string[]; notes: number[] };
export const melodies: Melody[] = [
{title:'Twinkle, Twinkle, Little Star',aliases:['twinkle twinkle little star','twinkle twinkle'],notes:[60,60,67,67,69,69,67,0,65,65,64,64,62,62,60]},
{title:'Ode to Joy',aliases:['ode to joy'],notes:[64,64,65,67,67,65,64,62,60,60,62,64,64,62,62]},
{title:'Frère Jacques',aliases:['frere jacques','are you sleeping'],notes:[60,62,64,60,60,62,64,60,64,65,67,0,64,65,67]},
{title:'Mary Had a Little Lamb',aliases:['mary had a little lamb'],notes:[64,62,60,62,64,64,64,0,62,62,62,0,64,67,67]},
{title:'Jingle Bells',aliases:['jingle bells'],notes:[64,64,64,0,64,64,64,0,64,67,60,62,64]},
{title:'London Bridge Is Falling Down',aliases:['london bridge is falling down','london bridge'],notes:[67,69,67,65,64,65,67,0,62,64,65,0,64,65,67]},
{title:'Old MacDonald Had a Farm',aliases:['old macdonald had a farm','old macdonald','old mcdonald'],notes:[60,60,60,55,57,57,55,0,64,64,62,62,60]},
{title:'Row, Row, Row Your Boat',aliases:['row row row your boat','row your boat'],notes:[60,60,60,62,64,0,64,62,64,65,67,0,72,72,72,67,67,67,64,64,64,60,60,60]},
];
export const categories = ['trending','rap','pop','rock','indie'] as const;
export type Category = typeof categories[number];
export function normalize(s:string){return s.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]/g,'');}
export function correctAnswer(song:Melody, answer:string){return [song.title,...song.aliases].some(a=>normalize(a)===normalize(answer));}
export function shuffledSongs(){return melodies.map((_,i)=>({i,r:crypto.getRandomValues(new Uint32Array(1))[0]})).sort((a,b)=>a.r-b.r).slice(0,5).map(x=>x.i);}
