CREATE TABLE `guesses` (
	`room` text NOT NULL,
	`round` integer NOT NULL,
	`player` text NOT NULL,
	`correct` integer NOT NULL,
	`answer` text NOT NULL,
	PRIMARY KEY(`room`, `round`, `player`)
);
--> statement-breakpoint
CREATE INDEX `guesses_player` ON `guesses` (`player`);--> statement-breakpoint
CREATE TABLE `members` (
	`room` text NOT NULL,
	`player` text NOT NULL,
	PRIMARY KEY(`room`, `player`)
);
--> statement-breakpoint
CREATE TABLE `players` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`avatar` integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE TABLE `rooms` (
	`code` text PRIMARY KEY NOT NULL,
	`host` text NOT NULL,
	`category` text NOT NULL,
	`status` text NOT NULL,
	`round` integer DEFAULT 0 NOT NULL,
	`songs` text NOT NULL,
	`started` integer DEFAULT 0 NOT NULL,
	`created` integer NOT NULL
);
