# TuneGuessr

A free, ad-free music guessing party game with light, dark and system themes. Built with React, TypeScript, Vinext and a Cloudflare Worker API backed by D1. Created by Mike Wong as a portfolio project.

## Important: the music is placeholder audio

**TuneGuessr does not currently include or stream copyrighted popular-song recordings. I have not obtained the licenses or provider approval needed to use those recordings in the game.**

The built-in audio is temporary, royalty-free filler: synthesized public-domain melodies, mostly familiar children’s songs such as *Twinkle, Twinkle, Little Star*, *Mary Had a Little Lamb*, and *Row, Row, Row Your Boat*. These are demo sounds used to showcase the game mechanics—not Spotify songs or a current chart catalog.

My goal is to replace this filler with actual song intros once I find a workable, authorized solution, such as a licensed clip provider or permission from rights holders. Until then, every online genre category uses the same demo catalog. The separate local-file mode can play recordings a user supplies; it does not provide those recordings or grant rights to share or broadcast them.

<p align="center"><img src="public/mascot.png" alt="TuneGuessr headphone mascot" width="180" /></p>

## Play

Choose a nickname and avatar, pick Trending, Rap, Pop, Rock or Indie, then:

- **Play solo:** signed-in players earn saved scores; anonymous players get local practice.
- **Create a room:** share the six-letter code or invite link, then start when everyone joins. Supports up to 12 players.
- **Join a room:** enter the host’s code before the game starts.
- **Each round:** tap play, name the song and lock in one answer within 25 seconds. The answer appears when all players submit or time expires. The host advances through five rounds.
- **Leaderboard:** total correctly named demo melodies across signed-in games. Scores are checked on the server. Local practice is excluded.
- **Stream view:** hides page navigation and footer. Use window capture with OBS or your streaming app. Each player plays audio in their own browser.

The initial hosted preview is owner-private. Invite links do not change access permissions. Change the Site’s audience before inviting other accounts.

## Status

| Capability | Status |
| --- | --- |
| Solo game, audio, typed guesses, results | Working |
| Rooms, shared round timer, host controls | Server implementation; polling every 1.5 seconds |
| Profiles and global demo scores | D1-backed |
| Tutorial and desktop/mobile layouts | Working |
| Stream layout and room invites | Working; not native platform integrations |
| Google / email / Spotify sign-in | Disabled in UI; configuration and compatible auth deployment required |
| Beta sign-in | Platform-managed ChatGPT identity |
| Spotify playlist import and playback | Not connected; requires separate Spotify approval |
| Trending / Rap / Pop / Rock / Indie | Selectable category metadata; all use the same demo melodies |
| Monetization | Removed: no ads, subscriptions, paid upgrades or checkout |
| Local audio intros | Select up to 100 device audio files; edit answer titles; play up to five random 1/3/6/12-second intros |
| Discord Activity / Twitch, Kick, TikTok bots | Not implemented; links and window capture available |

## Music source

Spotify’s developer policy prohibits games and trivia using its platform: https://developer.spotify.com/policy. This version neither calls Spotify nor uses Spotify audio or playlist metadata. It does not invent “Top 100 Pop/Rock/Indie” playlist IDs.

The catalog contains newly synthesized renditions of eight public-domain compositions, not commercial recordings. `lib/catalog.ts` defines answer rules and demo notes; `lib/audio.ts` renders notes with Web Audio. Categories share the demo catalog until a licensed source is supplied. A production provider needs approved catalog IDs and rights covering gameplay and streaming. Replace catalog selection and the audio adapter; do not assume preview URLs grant game or broadcast rights.

## Architecture and mobile path

- `app/page.tsx`: responsive UI and ephemeral round state.
- `app/api/game/route.ts`: JSON API for profile, rooms and game progression. Queries use bound parameters.
- `lib/catalog.ts`: platform-neutral melody model, normalization and matching.
- `lib/audio.ts`: isolated browser audio adapter.
- `db/schema.ts`, `drizzle/`: persistent data and migrations.
- `public/manifest.webmanifest`: standalone-shell metadata; network required for rooms and saved scores.

For iOS/Android, reuse the rules and JSON API in React Native/Expo, or refactor the client into a static SPA before packaging with Capacitor. The Worker cannot be bundled into a local mobile application. Add native audio/authentication adapters, deep links, lifecycle/reconnect handling and app lifecycle handling. The current trusted hosting boundary injects identity headers; a native API must validate real OAuth sessions/tokens instead. Never accept client-supplied user IDs or expose an untrusted header-based identity endpoint. No native app or app-store submission is included.

### API

`GET /api/game` returns profile, current user ID and top 25 scores. `GET /api/game?room=CODE` requires membership and returns round state, notes, players and submitted flags. Answers are withheld until the round ends.

`POST /api/game` accepts:

- `{ action: "profile", name, avatar }`
- `{ action: "create", category, solo }`
- `{ action: "join", code }`
- `{ action: "start", code }` — host only
- `{ action: "guess", code, round, answer }` — one submission per round
- `{ action: "next", code, round }` — host only, completed round

Identity comes only from the trusted dispatcher. Mutations validate origin when supplied. Unique database keys prevent double scoring; round predicates prevent stale submissions and duplicate advancement. Nicknames are displayed in rooms/leaderboard; emails are not returned. This demo leaderboard is not a production anti-cheat system.

## Development

Node 22.13+ and pnpm (see `pnpm-lock.yaml`):

```sh
pnpm install --frozen-lockfile
pnpm exec tsc --noEmit
pnpm run db:generate
pnpm run build
```

Use bundled Sites scripts to run and publish on the managed platform. Logical database binding is `DB` in `.openai/hosting.json`; migrations apply before deployment. Standalone development needs local D1 and a properly configured local identity adapter. Never ship a fake identity fallback.

## Before public launch

Connect a licensed music catalog; configure supported public authentication; add native streaming integrations if needed. Test concurrent clients, audio on iOS/Android, reconnect behavior, abuse limits and accessibility. Stream view does not relay third-party copyrighted audio.


## Theme and real-recording mode

The header has System, Light and Dark choices. System is the default, updates live when OS appearance changes, and manual selections persist locally on this device. An early theme script minimizes flashes on reload.

Choose **Play intros from your audio files** for local recordings. Audio is read via session-only blob URLs, not uploaded, indexed on the server, or saved in browser storage. Closing this mode revokes its URLs. Filenames seed editable answers; users should remove artist prefixes or track numbering. Supported codecs depend on the browser. Scores are local only; this mode does not distribute files to multiplayer rooms or clear livestream rights.

Removing monetization does not create nonprofit legal status or automatically make copyrighted audio fair use. There is no blanket safe excerpt length. See the US Copyright Office: https://www.copyright.gov/fair-use/.

### Popular-song catalog access

No popular-song recordings were automatically fetched or bundled in this update. Possible providers to contact:

- Songclip: https://github.com/songclip/songclip — licensed popular-song clip API; access requests described in the official client README. Warner announced integrations including games: https://www.wmg.com/news/warner-music-group-partners-songclip-power-music-feature-35511. Confirm current access, territory, title-hiding, game use, streaming and reporting terms before integration.
- Feed Clips: https://clips.feed.fm/docs/ — popular music clips, primarily positioned for UGC. Quiz/game use is not established by that documentation and needs explicit confirmation.

FMA/CC0 catalogs can provide authorized recordings but are not substitutes for current chart hits. The shipped demo remains available; local mode can play actual recordings supplied by the user with appropriate authorization.
