import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "TuneGuessr — Name that tune",
  description: "A little friendly competition. Listen, name the song, and play five-round music parties with friends.",
  other: {
    "codex-preview": "development",
  },
  manifest: "/manifest.webmanifest",
  appleWebApp: { capable: true, title: "TuneGuessr", statusBarStyle: "default" },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head><script dangerouslySetInnerHTML={{__html: `(function(){try{var t=localStorage.getItem("tg-theme");document.documentElement.dataset.theme=t==="light"||t==="dark"?t:(matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light");}catch(e){}})()`}} /></head>
      <body className="antialiased">{children}</body>
    </html>
  );
}
