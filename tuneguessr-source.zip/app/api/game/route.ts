import { env } from 'cloudflare:workers';
import { categories, melodies, shuffledSongs, correctAnswer } from '@/lib/catalog';
export const dynamic='force-dynamic';
type Room={code:string;host:string;category:string;status:string;round:number;songs:string;started:number;created:number};
class GameError extends Error { constructor(message:string,public status=400){super(message);} }
const db=()=>{if(!env.DB)throw new GameError('Scores are temporarily unavailable. Please try again.');return env.DB;};
const json=(data:unknown,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store'}});
function identity(req:Request){return req.headers.get('oai-authenticated-user-id');}
async function roomState(code:string,id:string){
 const r=await db().prepare('SELECT * FROM rooms WHERE code=?').bind(code).first<Room>();
 if(!r)throw new GameError('Room not found. Check the six-letter code.',404);
 const member=await db().prepare('SELECT player FROM members WHERE room=? AND player=?').bind(code,id).first();
 if(!member)throw new GameError('Join this room first.',403);
 const people=await db().prepare('SELECT p.id,p.name,p.avatar,COALESCE(SUM(g.correct),0) score FROM members m JOIN players p ON p.id=m.player LEFT JOIN guesses g ON g.player=p.id AND g.room=m.room WHERE m.room=? GROUP BY p.id ORDER BY score DESC,p.name').bind(code).all();
 const submitted=await db().prepare('SELECT player,correct FROM guesses WHERE room=? AND round=?').bind(code,r.round).all<{player:string;correct:number}>();
 const done=r.status==='playing'&&(Date.now()>=r.started+25000||submitted.results.length>=people.results.length);
 const song=melodies[JSON.parse(r.songs)[r.round]];
 return {code:r.code,category:r.category,status:r.status,round:r.round,started:r.started,serverNow:Date.now(),host:r.host===id,players:people.results,submitted:submitted.results.map(s=>s.player),mine:submitted.results.find(s=>s.player===id)??null,done,notes:r.status==='playing'?song.notes:[],answer:done?song.title:null,total:5};
}
export async function GET(req:Request){try{
 const id=identity(req), url=new URL(req.url),code=url.searchParams.get('room');
 if(code){if(!id)return json({error:'Sign in to join a room.'},401);return json(await roomState(code,id));}
 const board=await db().prepare('SELECT p.name,p.avatar,SUM(g.correct) score FROM players p JOIN guesses g ON p.id=g.player GROUP BY p.id HAVING SUM(g.correct)>0 ORDER BY score DESC,p.name LIMIT 25').all();
 const profile=id?await db().prepare('SELECT name,avatar FROM players WHERE id=?').bind(id).first():null;
 return json({board:board.results,profile,userId:id});
}catch(e){console.error(e instanceof Error?e.message:e);return json({error:e instanceof GameError?e.message:'Unable to load the game. Please try again.'},e instanceof GameError?e.status:503);}}
export async function POST(req:Request){try{
 const id=identity(req);if(!id)return json({error:'Sign in with ChatGPT to save scores and play online.'},401);
 const origin=req.headers.get('origin');if(origin&&origin!==new URL(req.url).origin)return json({error:'Invalid origin.'},403);
 const b=await req.json() as Record<string,unknown>; const action=String(b.action??'');
 if(action==='profile'){
 const name=String(b.name??'').trim().slice(0,20);if(!name)return json({error:'Choose a nickname first.'},400);
 const avatar=Math.max(0,Math.min(5,Math.floor(Number(b.avatar)||0)));
 await db().prepare('INSERT INTO players(id,name,avatar) VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,avatar=excluded.avatar').bind(id,name,avatar).run();return json({ok:true});}
 const p=await db().prepare('SELECT id FROM players WHERE id=?').bind(id).first();if(!p)return json({error:'Choose a nickname first.'},400);
 if(action==='create'){
 const category=String(b.category);if(!categories.includes(category as typeof categories[number]))return json({error:'Choose a category.'},400);
 const recent=await db().prepare('SELECT COUNT(*) n FROM rooms WHERE host=? AND created>?').bind(id,Date.now()-60000).first<{n:number}>();if((recent?.n??0)>=10)return json({error:'Please wait a minute before creating another room.'},429);
 const code=Array.from(crypto.getRandomValues(new Uint8Array(6)),n=>'ABCDEFGHJKLMNPQRSTUVWXYZ'[n%24]).join('');
 await db().batch([db().prepare('INSERT INTO rooms(code,host,category,status,round,songs,started,created) VALUES(?,?,?,?,?,?,?,?)').bind(code,id,category,b.solo?'playing':'lobby',0,JSON.stringify(shuffledSongs()),b.solo?Date.now():0,Date.now()),db().prepare('INSERT INTO members(room,player) VALUES(?,?)').bind(code,id)]);
 return json(await roomState(code,id));}
 const code=String(b.code??'').toUpperCase(); const r=await db().prepare('SELECT * FROM rooms WHERE code=?').bind(code).first<Room>();if(!r)return json({error:'Room not found. Check the code and try again.'},404);
 if(action==='join'){
 if(r.status!=='lobby')return json({error:'This game has started. Ask the host to create a new room.'},409);
 await db().prepare('INSERT OR IGNORE INTO members(room,player) SELECT ?,? WHERE (SELECT COUNT(*) FROM members WHERE room=?)<12 AND EXISTS (SELECT 1 FROM rooms WHERE code=? AND status=?)').bind(code,id,code,code,'lobby').run();return json(await roomState(code,id));}
 const state=await roomState(code,id);
 if(action==='guess'){
 if(r.status!=='playing'||state.done||Number(b.round)!==r.round)return json({error:'This round has ended.'},409);
 const answer=String(b.answer??'').trim().slice(0,100);if(!answer)return json({error:'Type a song title.'},400);
 const song=melodies[JSON.parse(r.songs)[r.round]];const correct=correctAnswer(song,answer)?1:0;
 await db().prepare('INSERT OR IGNORE INTO guesses(room,round,player,correct,answer) SELECT ?,?,?,?,? WHERE EXISTS (SELECT 1 FROM rooms WHERE code=? AND round=? AND status=? AND started>?)').bind(code,r.round,id,correct,answer,code,r.round,'playing',Date.now()-25000).run();
 }else if(action==='start'||action==='next'){
 if(r.host!==id)return json({error:'Only the host can advance the game.'},403);
 if(action==='start'&&r.status==='lobby')await db().prepare('UPDATE rooms SET status=?,started=? WHERE code=? AND status=?').bind('playing',Date.now(),code,'lobby').run();
 else if(action==='next'&&r.status==='playing'&&state.done){if(Number(b.round)!==r.round)return json(state);await db().prepare('UPDATE rooms SET status=?,round=?,started=? WHERE code=? AND round=?').bind(r.round===4?'finished':'playing',r.round===4?4:r.round+1,Date.now(),code,r.round).run();}
 else return json({error:'Wait until the round ends.'},409);
 }else return json({error:'Unknown action.'},400);
 return json(await roomState(code,id));
}catch(e){console.error(e instanceof Error?e.message:e);return json({error:e instanceof GameError?e.message:'Unable to save. Please try again.'},e instanceof GameError?e.status:503);}}
